package br.com.joalheriajoiasjoia.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JoalheriaJoiasJoiaStApplication {

	public static void main(String[] args) {
		SpringApplication.run(JoalheriaJoiasJoiaStApplication.class, args);
	}

}
