package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entities.Funcionario;
import com.example.demo.Repository.FuncionarioRepository;

@Service
public class FuncionarioService {
	
	@Autowired
	private FuncionarioRepository funcionarioRepository;
	
	public List<Funcionario> getAllFuncionario(){
		return funcionarioRepository.findAll();
	}
	public Funcionario getFuncionarioPorId(Long id) {
		return funcionarioRepository.findById(id).orElse(null);
	}
	public Funcionario buscarFuncionarioPorCpf(String cpf) {
		return funcionarioRepository.findByCpf(cpf);
	}
	public Funcionario saveFuncionario(Funcionario funcionario) {
		return funcionarioRepository.save(funcionario);
	}
	public void deleteFuncionario(Long id) {
		funcionarioRepository.deleteById(id);
	}
	public Funcionario getFuncionarioById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

}
