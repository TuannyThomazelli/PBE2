package com.example.demo.Entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_funcionario")
public class Funcionario {
	
	// atributos 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id_funcionario;
	
	@Column(name = "nome", nullable = false, length = 10)
	private String nome;
	
	@Column(name = "telefone", nullable = false, length = 11)
	private int telefone;
	
	@Column(name = "cpf", nullable = false, length = 11)
	private String cpf;
	
	@Column(name = "endereco", nullable = false, length = 11)
	private String endereco;
	
	// construtores 
	
	public Funcionario() {
		
	}
	public Funcionario(Long id_funcionario, String nome, int telefone, String cpf, String endereco ) {
	this.id_funcionario = id_funcionario;
	this.nome = nome;
	this.telefone= telefone;
	this.cpf =cpf;
	this.endereco= endereco;
	}
	
	//Getters e setters 
	public Long getId_funcionario() {
		return id_funcionario;
	}
	public void setId_funcionario(Long id_funcionario) {
		this.id_funcionario = id_funcionario;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getTelefone() {
		return telefone;
	}
	public void setTelefone(int telefone) {
		this.telefone = telefone;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	
	
}
